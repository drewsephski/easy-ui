import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export type Input = ClassValue[];

export function cn(...inputs: Input) {
  return twMerge(clsx(inputs));
}
