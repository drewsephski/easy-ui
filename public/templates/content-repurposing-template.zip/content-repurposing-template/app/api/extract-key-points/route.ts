import { GoogleGenerativeAI } from '@google/generative-ai';

export async function POST(request: Request) {
  const { text } = await request.json();

  if (!text) {
    return new Response(JSON.stringify({ error: 'No text provided' }), { status: 400 });
  }

  const apiKey = request.headers.get('x-api-key');

  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'API key not provided' }), { status: 401 });
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = `Please extract the key points from the following text: ${text}`;

    const result = await model.generateContent(prompt);
    const response = result.response;
    const keyPoints = response.text();

    return new Response(JSON.stringify({ keyPoints }), { status: 200 });
  } catch (error) {
    console.error('Error calling Gemini API for key point extraction:', error);
    return new Response(JSON.stringify({ error: 'Failed to extract key points with AI' }), { status: 500 });
  }
}