import { GoogleGenerativeAI } from '@google/generative-ai';

export async function POST(request: Request) {
  const apiKey = request.headers.get('x-api-key');

  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'API key not provided' }), { status: 401 });
  }

  const genAI = new GoogleGenerativeAI(apiKey);
  const { text } = await request.json();

  if (!text) {
    return new Response(JSON.stringify({ error: 'No text provided' }), { status: 400 });
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = `Please generate social media snippets from the following text: ${text}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const socialMediaSnippets = response.text();

    return new Response(JSON.stringify({ socialMediaSnippets }), { status: 200 });
  } catch (error) {
    console.error('Error calling Gemini API for social media snippets:', error);
    return new Response(JSON.stringify({ error: 'Failed to generate social media snippets with AI' }), { status: 500 });
  }
}