import { GoogleGenerativeAI } from '@google/generative-ai';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { text } = await req.json();
    const apiKey = req.headers.get('x-api-key');

    if (!apiKey) {
      return NextResponse.json({ error: 'API key is missing' }, { status: 400 });
    }

    if (!text) {
      return NextResponse.json({ error: 'Text is missing from request body' }, { status: 400 });
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = `Summarize the following text:\n\n${text}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const summarizedText = response.text();

    return NextResponse.json({ processedText: summarizedText });
  } catch (error: any) {
    console.error('Error summarizing text:', error);
    return NextResponse.json({ error: error.message || 'Failed to summarize text' }, { status: 500 });
  }
}