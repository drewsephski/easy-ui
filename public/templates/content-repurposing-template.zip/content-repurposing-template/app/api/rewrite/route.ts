import { GoogleGenerativeAI } from '@google/generative-ai';

export async function POST(request: Request) {
  const apiKey = request.headers.get('x-api-key');

  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'API key not provided' }), { status: 401 });
  }

  const { text } = await request.json();

  if (!text) {
    return new Response(JSON.stringify({ error: 'No text provided' }), { status: 400 });
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = `Please rewrite and summarize the following text: ${text}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const rewrittenText = response.text();

    return new Response(JSON.stringify({ rewrittenText }), { status: 200 });
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    return new Response(JSON.stringify({ error: 'Failed to process text with AI' }), { status: 500 });
  }
}
