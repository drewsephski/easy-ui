import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY as string);

export async function POST(request: Request) {
  const { text } = await request.json();

  if (!text) {
    return new Response(JSON.stringify({ error: 'No text provided' }), { status: 400 });
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });

    const prompt = `Please suggest headlines and titles for the following text: ${text}`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const headlinesTitles = response.text();

    return new Response(JSON.stringify({ headlinesTitles }), { status: 200 });
  } catch (error) {
    console.error('Error calling Gemini API for headlines/titles:', error);
    return new Response(JSON.stringify({ error: 'Failed to generate headlines/titles with AI' }), { status: 500 });
  }
}