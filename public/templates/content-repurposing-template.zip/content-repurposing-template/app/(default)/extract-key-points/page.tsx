"use client";

import React, { useState } from 'react';
import { TextGenerateEffect } from '@/components/ui/text-generate-effect';
import Toast from '@/components/ui/Toast'; // Import the Toast component

export default function ExtractKeyPointsPage() {
  const [inputText, setInputText] = useState('');
  const [keyPoints, setKeyPoints] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('error');

  const handleExtractKeyPoints = async () => {
    setLoading(true);
    setError(null);
    setShowToast(false); // Hide any previous toast
    try {
      const response = await fetch('/api/extract-key-points', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': localStorage.getItem('gemini_api_key') || '',
        },
        body: JSON.stringify({ text: inputText }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        const errorMessage = errorData.error || 'Something went wrong';
        
        // Check for the specific quota error message
        if (errorMessage.includes('Quota exceeded') || errorMessage.includes('The model is overloaded')) {
          setToastMessage('You need funds in your Gemini account or the model is overloaded. Please try again later.');
          setToastType('error');
          setShowToast(true);
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      setKeyPoints(data.keyPoints);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="relative">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="pb-12 pt-32 md:pb-20 md:pt-40">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-3xl mb-4">Extract Key Points</h1>
            <p className="text-xl text-gray-400">Enter your text below to extract key points using AI.</p>
          </div>
          <div className="mx-auto mt-8 max-w-3xl">
            <div className="mb-4">
              <label htmlFor="inputText" className="mb-2 block text-sm font-medium text-gray-300">Input Text</label>
              <textarea
                id="inputText"
                className="form-textarea w-full rounded-md border border-gray-700 bg-gray-800 px-4 py-3 text-gray-200 focus:border-purple-500 focus:ring-purple-500"
                rows={8}
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Paste your text here..."
              ></textarea>
            </div>

            <div className="mb-6">
              <button
                onClick={handleExtractKeyPoints}
                className="btn-sm w-full bg-linear-to-t from-indigo-600 to-indigo-500 bg-[length:100%_100%] bg-[bottom] py-[5px] text-white shadow-[inset_0px_1px_0px_0px_--theme(--color-white/.16)] hover:bg-[length:100%_150%]"
                disabled={loading}
              >
                {loading ? 'Processing...' : 'Extract Key Points'}
              </button>
            </div>

            {error && (
              <div className="mb-4 text-center text-red-500">
                {error}
              </div>
            )}

            {keyPoints && (
              <div className="mt-8">
                <h2 className="mb-4 text-center text-2xl font-bold text-gray-200">Extracted Key Points:</h2>
                <div className="rounded-md border border-gray-700 bg-gray-800 p-4">
                  <TextGenerateEffect words={keyPoints} className="text-gray-200" />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {showToast && (
        <Toast
          message={toastMessage}
          type={toastType}
          onClose={() => setShowToast(false)}
        />
      )}
    </section>
  );
}
