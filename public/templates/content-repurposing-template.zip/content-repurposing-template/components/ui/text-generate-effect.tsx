"use client";
import { useEffect, useRef } from "react";
import { motion, useInView, useAnimation } from "framer-motion";
import { cn } from "@/lib/utils";

export const TextGenerateEffect = ({ words, className }: { words: string; className?: string }) => {
  const controls = useAnimation();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  const wordsArray = words.split(" ");

  useEffect(() => {
    if (isInView) {
      controls.start("visible");
    } else {
      controls.stop();
    }
  }, [isInView, controls]);

  const renderWords = () => {
    return (
      <motion.div ref={ref} className="mt-4 font-normal text-[var(--color-gray-200)] text-sm leading-relaxed">
        {wordsArray.map((word, idx) => (
          <motion.span
            key={word + idx}
            initial={{ opacity: 0 }}
            animate={controls}
            variants={{
              visible: {
                opacity: 1,
                transition: {
                  delay: idx * 0.1,
                },
              },
            }}
            className="text-[var(--color-gray-800)]"
          >
            {word}{" "}
          </motion.span>
        ))}
      </motion.div>
    );
  };

  return (
    <div className={cn("font-bold", className)}>
      <div className="my-4">
        {renderWords()}
      </div>
    </div>
  );
};