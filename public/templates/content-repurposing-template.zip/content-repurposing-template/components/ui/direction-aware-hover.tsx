"use client";

import React, { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";

export const DirectionAwareHover = ({
  imageUrl,
  children,
  childrenClassName,
  className,
}: {
  imageUrl: string;
  children: React.ReactNode;
  childrenClassName?: string;
  className?: string;
}) => {
  const ref = useRef<HTMLDivElement>(null);

  const [direction, setDirection] = useState<"top" | "bottom" | "left" | "right" | string>("left");

  const handleMouseEnter = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!ref.current) return;

    const x = event.pageX - ref.current.offsetLeft;
    const y = event.pageY - ref.current.offsetTop;

    const width = ref.current.offsetWidth;
    const height = ref.current.offsetHeight;

    const hypotenuse = Math.sqrt(width * width + height * height);
    const angle = Math.atan2(y - height / 2, x - width / 2);

    const angleDeg = (angle * 180) / Math.PI;

    if (angleDeg >= -45 && angleDeg < 45) {
      setDirection("right");
    } else if (angleDeg >= 45 && angleDeg < 135) {
      setDirection("bottom");
    } else if (angleDeg >= 135 || angleDeg < -135) {
      setDirection("left");
    } else {
      setDirection("top");
    }
  };

  return (
    <motion.div
      onMouseEnter={handleMouseEnter}
      ref={ref}
      className={cn(
        "relative w-full h-full overflow-hidden bg-[var(--color-gray-900)] rounded-lg",
        className || ''
      )}
    >
      <AnimatePresence mode="wait">
        <motion.div
          className="relative h-full w-full"
          initial="initial"
          whileHover={direction}
          exit="exit"
          variants={{
            initial: {
              x: 0,
            },

            left: {
              x: "-100%",
              opacity: 0,
            },

            right: {
              x: "100%",
              opacity: 0,
            },

            top: {
              y: "-100%",
              opacity: 0,
            },

            bottom: {
              y: "100%",
              opacity: 0,
            },

            exit: {
              x: 0,
              y: 0,
              opacity: 1,
            },
          }}
        >
          <img
            src={imageUrl}
            alt="image"
            className="h-full w-full object-cover scale-[1.15]"
          />
        </motion.div>

        <motion.div
          initial="initial"
          whileHover={direction}
          exit="exit"
          variants={{
            initial: {
              x: 0,
              y: 0,
            },

            left: {
              x: 0,
              y: 0,
            },

            right: {
              x: 0,
              y: 0,
            },

            top: {
              x: 0,
              y: 0,
            },

            bottom: {
              x: 0,
              y: 0,
            },

            exit: {
              x: 0,
              y: 0,
            },
          }}
          className={cn(
            "absolute inset-0 flex items-center justify-center flex-col text-[var(--color-gray-200)]",
            childrenClassName
          )}
        >
          {children}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
};