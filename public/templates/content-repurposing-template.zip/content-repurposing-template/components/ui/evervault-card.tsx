"use client";
import { cn } from "@/lib/utils";
import React from "react";
import { motion } from "framer-motion";

export const EvervaultCard = ({ text, className }: { text?: string; className?: string }) => {
  const colors = [
    "var(--color-gray-500)",
    "var(--color-indigo-500)",
    "var(--color-indigo-600)",
    "var(--color-indigo-700)",
    "var(--color-indigo-800)",
    "var(--color-indigo-900)",
    "var(--color-gray-200)",
    "var(--color-gray-300)",
    "var(--color-gray-400)",
    "var(--color-gray-500)",
    "var(--color-gray-600)",
    "var(--color-gray-700)"
  ];

  const randomString = (length: number) => {
    let result = "";
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  };

  return (
    <div
      className={cn(
        "border border-[var(--color-gray-700)] flex flex-col items-start max-w-sm mx-auto p-4 relative h-[30rem]",
        typeof className === 'boolean' ? '' : className
      )}
    >
      <div className="relative z-10 flex flex-col items-start h-full justify-between">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="font-bold text-[var(--color-gray-200)] text-4xl pointer-events-none"
          >
            {text}
          </motion.div>
          <button className="px-4 py-2 rounded-full border border-[var(--color-gray-700)] text-[var(--color-gray-200)] text-sm">
            Hover
          </button>
        </div><motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute inset-0 h-full w-full bg-[var(--color-gray-900)] z-0 flex items-center justify-center text-[var(--color-gray-200)] font-bold"
        >
            <div className="grid grid-cols-10 gap-2 p-4">
              {Array.from({ length: 100 }).map((_, i) => (
                <span
                  key={i}
                  className="text-xs uppercase text-[var(--color-gray-500)]"
                  style={{ color: colors[Math.floor(Math.random() * colors.length)] }}
                >
                  {randomString(3)}
                </span>
              ))}
            </div>
          </motion.div>
    </div>
  );
};

export default EvervaultCard;