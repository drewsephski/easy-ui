"use client";
import React, { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const BackgroundBeams = ({ className, ...rest }: { className?: string }) => {
  const [interactive, setInteractive] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setMousePosition({
          x: event.clientX - rect.left,
          y: event.clientY - rect.top,
        });
      }
    };

    if (interactive) {
      window.addEventListener("mousemove", handleMouseMove);
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, [interactive]);

  const beams = Array.from({ length: 10 }).map((_, i) => {
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    const duration = Math.random() * 5 + 5; // 5-10 seconds
    const delay = Math.random() * 2;

    const style: React.CSSProperties = {
      left: `${x}%`,
      top: `${y}%`,
      animation: `beam-move-${i} ${duration}s infinite linear`,
      animationDelay: `${delay}s`,
    };

    if (interactive) {
      const dx = mousePosition.x - (x / 100) * (containerRef.current?.offsetWidth || 0);
      const dy = mousePosition.y - (y / 100) * (containerRef.current?.offsetHeight || 0);
      const angle = Math.atan2(dy, dx) * (180 / Math.PI);
      style.transform = `rotate(${angle + 90}deg)`;
    }

    return (
      <motion.div
        key={i}
        className="absolute h-px w-[var(--beam-width)] bg-gradient-to-r from-transparent via-[var(--color-indigo-500)] to-transparent"
        style={style}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5, delay: delay }}
      />
    );
  });

  return (
    <div
      ref={containerRef}
      className={cn(
        "h-screen w-full relative flex items-center justify-center antialiased",
        className
      )}
      {...rest}
    >
      <div className="absolute inset-0 pointer-events-none">
        {beams}
      </div>
      <style jsx>{`
        @keyframes beam-move {
          0% { transform: translateY(0) rotate(0deg); }
          100% { transform: translateY(100vh) rotate(360deg); }
        }
        .h-px {
          height: 1px;
        }
        .w-\[var\(--beam-width\)\] {
          width: var(--beam-width);
        }
      `}</style>
    </div>
  );
};